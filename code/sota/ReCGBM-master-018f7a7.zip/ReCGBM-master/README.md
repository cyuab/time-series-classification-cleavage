# ReCGBM

Setting up environment using conda
1. Install anaconda (64 bit)installer python3.x for linux.
2. git clone https://github.com/ryuu90/ReCGBM.git
3. cd ReCGBM
4. conda env create -f environment.yml
5. conda activate ReCGBM

Run verify.py by python verify.py, you can check the results of 10 trained gradient boosting model in our paper.

Run train.py by python train.py, you can train and test on an example dataset through our method.
